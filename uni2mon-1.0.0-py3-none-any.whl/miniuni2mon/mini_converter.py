def hello_mon(text):
    return "MON says: " + text
