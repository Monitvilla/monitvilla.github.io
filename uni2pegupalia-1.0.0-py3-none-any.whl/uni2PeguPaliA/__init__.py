from .converter import convert_to_PeguPaliA
